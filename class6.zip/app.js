
// const food = [ 'bereyani', 'apple', 'kola', 'lao', 'potol', 'kumra' ];
// // console.log( food.length);
// const pakhi = ["moyna", "tiya", "shalikh", "borta", "kobutor", "kak", "chil", "shokun", "payra", "dueal"];


// for (let i = 0; i < pakhi.length; i++) {
//     console.log( (i+1) + " "+ pakhi[i]);
    
// }
// pakhi.forEach( data => console.log(data));

// const devs = [
// ['habib',12,'php','uttora'],
// ['rakib',40,'python','mirpur'],
// ['robin',200,'laravel','bonani'],
// ['raihan',120,'php','mirpur'],
// ['josim',80,'pytho','uttora'],
// ['asad',90,'laravel','bonani'],
// ['emon',100,'php','mirpur'],
// ['shakib',120,'pytho','uttora'],

// ];
// for (let i = 0; i < devs.length; i++) {
//     // console.log(devs[i]);
    
//     if (devs[i][2] == 'php' || devs[i][3]=='bonani' && devs[i][1] > 120) {
//         console.log(`=============================`);
//         devs[i].map((data) => console.log(data));
//         console.log(`==============================`); 
//     }
    
// }